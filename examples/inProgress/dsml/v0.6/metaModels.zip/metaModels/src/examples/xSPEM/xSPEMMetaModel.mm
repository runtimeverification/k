metamodel xSPEM  
{
    enumeration activityState
      {
        notStarted; inProgress; finished
      }

    enumeration timeState
      {
        undefined; tooEarly; ok; tooLate
      }


	class process 
		{ 
			attribute time : int;
			reference activities : activity;
		}

	class activity extends {process}
		{
			attribute tmin : int;
            attribute tmax : int;
            attribute aS : activityState;
            attribute tS : timeState;
			reference linkToPredecessor : workSequence [1-1];
			reference resources : resource;
		}

	class workSequence 
		{
			reference startedToStart : activity; 
			reference startedToFinish : activity; 
			reference finishedToStart : activity;
			reference finishedToFinish : activity;
		}  

	class resource
	  {
	    attribute available : bool;
	  }

}
constraints
 {
 (allInstances(process).size() == 1)
 };