model onexSPEM : xSPEM = {

object p : process = 
  {
    time : int = 0;
    activities : activity = {a b};
  }
  
object a : activity = 
  {
    tmin : int = 5;
    tmax : int = 8;
    aS : activityState = notStarted;
    tS : timeState = undef;
    resources : resource = {r} ;
    time : int = 0;
    linkToPredecessor : workSequence = {w2};
    activities : activity = {};
  }
  


object b : activity = 
  {
    tmin : int = 5;
    tmax : int = 8;
    aS : activityState = notStarted;
    tS : timeState = undef;
    resources : resource = {r} ;
    time : int = 0;
    linkToPredecessor : workSequence = {w1};    
    activities : activity = {};
  }
  
object r: resource  = 
  { 
    available : bool = true;
  }  
  
object w1: workSequence = 
  {
    startedToStart : activity = {}; 
    startedToFinish : activity = {}; 
    finishedToStart : activity = {}; 
    finishedToFinish : activity = {a};
    
  }  
 
 object w2: workSequence = 
  {
    startedToStart : activity = {}; 
    startedToFinish : activity = {}; 
    finishedToStart : activity = {}; 
    finishedToFinish: activity = {};
    
  }  
   
}