metamodel Automata  {

	class automaton 
		{ 
			attribute trace : string;
			reference active : state [1 - 1];
		}

	class transition
		{
			attribute label : string;
			reference orig : state [1 - 1] oppositeOf out;
			reference dest : state [1 - 1] oppositeOf in;
		}

	class state 
		{
			reference in : transition oppositeOf dest;
			reference out : transition oppositeOf orig;
		}  

	class initialState extends {state} { }

}
constraints{
(allInstances(initialState).size() == 1) 
(allInstances(transition)->forAll(t | not(t.label == ""))) 
(allInstances(state)
 ->forAll(s |
          s.out
            ->forAll(t1 | 
                 s.out
                     ->forAll( t2 | 
                              ((t1.label) == (t2.label)) implies (t1 == t2)
                             )
                     )
          )                    
)
 }
;