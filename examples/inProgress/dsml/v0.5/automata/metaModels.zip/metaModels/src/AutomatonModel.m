model simple : automata  = {
	object a : automaton = 
	{
		trace  : string = "" ;
		active : state = {s0};
	}	

object s0 : state = 
	{
		in : transition = {t1};
		out : transition = {t1 t2};
	}

object s1 : state = 
	{
		in : transition = {t2 t3};
		out : transition = {t3};
	}

object t1 : transition = 
		{
			orig : state = {s0};
			dest : state = {s0};
			label : string  = "a";
		}

object t2 : transition = 
		{
			orig : state = {s0};
			dest : state = {s1};
			label : string = "a";       
		}


object t3 : transition = 
		{
			orig : state = {s1};
			dest : state = {s1};
			label : string = "c";  
		}
}