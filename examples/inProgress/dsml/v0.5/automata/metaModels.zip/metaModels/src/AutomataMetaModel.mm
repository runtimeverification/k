metamodel Automata  {
	
	class Automaton 
		{ 
			attribute trace : string;
			reference initialState : State [1 - 1];
			reference owned : Transition [1 - *];
		}
	
	class Transition 
		{
			attribute label : string;
			reference orig : State [1 - 1] oppositeOf out;
			reference dest : State [1 - 1] oppositeOf in;
		}
	
	class State 
		{
			reference in : Transition oppositeOf dest;
			reference out : Transition oppositeOf orig;
		}  
	
	class InitialState extends State  { }
	
}