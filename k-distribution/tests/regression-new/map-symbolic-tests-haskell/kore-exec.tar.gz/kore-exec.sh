#!/bin/sh
exec kore-exec \
    vdefinition.kore \
    --output result.kore \
    --module MAP-TESTS \
    --strategy all \
    --smt-timeout 40 \
    --smt-reset-interval 100 \
    --smt z3 \
    --log-level \
    warning \
    --enable-log-timestamps \
    --prove spec.kore \
    --spec-module REMOVE-12-SPEC \
    --graph-search breadth-first \
     \
     \
    "$@"
